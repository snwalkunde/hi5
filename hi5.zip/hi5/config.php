<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'bkUTuP3PtE4w9fyvB3LlkA');
define('CONSUMER_SECRET', 'GHNtXwBj5dMOdr9CrcnnmWF6T5Ivl7ZAPkP8O28jk');
define('OAUTH_CALLBACK', 'http://localdrupal.com/callback.php');
